import Link from "next/link"
import Image from "next/image"
import { Smartphone, ChevronRight, ShoppingCart, Star, Zap, Shield, Truck } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-white">
      {/* Header Premium */}
      <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-xl border-b border-gray-200/50">
        <div className="container flex h-16 items-center justify-between max-w-7xl mx-auto px-6">
          <Link href="/" className="flex items-center gap-3 font-semibold text-xl text-gray-900">
            <div className="h-9 w-9 bg-gradient-to-br from-gray-400 to-gray-600 rounded-xl flex items-center justify-center shadow-lg">
              <Smartphone className="h-5 w-5 text-white" />
            </div>
            <span className="bg-gradient-to-r from-gray-700 to-gray-900 bg-clip-text text-transparent">
              TechPremium
            </span>
          </Link>

          <nav className="hidden md:flex gap-8">
            <Link
              href="/productos/iphone"
              className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              iPhone
            </Link>
            <Link
              href="/productos/mac"
              className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              Mac
            </Link>
            <Link
              href="/productos/ipad"
              className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              iPad
            </Link>
            <Link
              href="/productos/accesorios"
              className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              Accesorios
            </Link>
            <Link href="/ofertas" className="text-sm font-medium text-red-600 hover:text-red-700 transition-colors">
              Ofertas
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link href="/carrito" className="relative p-2 hover:bg-gray-100 rounded-full transition-colors">
              <ShoppingCart className="h-5 w-5 text-gray-700" />
              <div className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-medium">2</span>
              </div>
            </Link>
            <Button variant="ghost" size="sm" className="hidden md:flex text-gray-600 hover:text-gray-900">
              Iniciar Sesión
            </Button>
            <Button size="sm" className="hidden md:flex bg-gray-900 hover:bg-gray-800 text-white">
              Registrarse
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Premium con Oferta Limitada */}
        <section className="relative w-full py-16 md:py-24 bg-gradient-to-br from-gray-50 via-white to-gray-100">
          <div className="absolute top-4 right-4 z-10">
            <Badge className="bg-red-500 text-white px-3 py-1 text-sm font-medium animate-pulse">
              Oferta por tiempo limitado
            </Badge>
          </div>

          <div className="container max-w-7xl mx-auto px-6 text-center">
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="inline-flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2 text-sm text-gray-700">
                  <Zap className="h-4 w-4 text-yellow-500" />
                  Nuevo iPhone 15 Pro disponible
                </div>
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight text-gray-900">
                  iPhone 15 Pro
                </h1>
                <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto font-light leading-relaxed">
                  Forjado en titanio. Potenciado por A17 Pro.
                  <span className="block mt-2 text-gray-900 font-medium">
                    La experiencia iPhone más avanzada hasta ahora.
                  </span>
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-medium rounded-full shadow-lg"
                >
                  Comprar desde $999
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-2 border-gray-300 text-gray-700 hover:bg-gray-50 px-8 py-4 text-lg font-medium rounded-full"
                >
                  Ver especificaciones
                </Button>
              </div>

              {/* Beneficios clave */}
              <div className="flex flex-wrap justify-center gap-6 pt-8">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Truck className="h-4 w-4 text-green-600" />
                  Envío gratis
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Shield className="h-4 w-4 text-blue-600" />
                  Garantía 2 años
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Star className="h-4 w-4 text-yellow-500" />
                  4.9/5 estrellas
                </div>
              </div>

              <div className="pt-12">
                <div className="relative h-[500px] md:h-[700px] max-w-5xl mx-auto">
                  <Image
                    src="/placeholder.svg?height=700&width=900&text=iPhone+15+Pro+Hero"
                    alt="iPhone 15 Pro"
                    fill
                    className="object-contain drop-shadow-2xl"
                    priority
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Sección de Urgencia - Ofertas Limitadas */}
        <section className="w-full py-16 bg-gray-900 text-white">
          <div className="container max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">Ofertas Flash</h2>
              <p className="text-xl text-gray-300 mb-6">Solo por 48 horas. Stock limitado.</p>
              <div className="inline-flex items-center gap-4 bg-red-600 rounded-full px-6 py-3">
                <span className="text-sm font-medium">Termina en:</span>
                <div className="flex gap-2 font-mono text-lg font-bold">
                  <span>23:45:12</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { nombre: "iPhone 14 Pro", precio: 899, precioOriginal: 1099, descuento: 18, stock: 5 },
                { nombre: "MacBook Air M2", precio: 1099, precioOriginal: 1299, descuento: 15, stock: 3 },
                { nombre: "iPad Pro 12.9", precio: 999, precioOriginal: 1199, descuento: 17, stock: 7 },
              ].map((producto, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                  <div className="relative mb-4">
                    <Badge className="absolute top-0 right-0 bg-red-500 text-white">-{producto.descuento}%</Badge>
                    <div className="h-48 bg-white/5 rounded-xl mb-4 flex items-center justify-center">
                      <Image
                        src={`/placeholder.svg?height=200&width=200&text=${producto.nombre.replace(/\s+/g, "+")}`}
                        alt={producto.nombre}
                        width={200}
                        height={200}
                        className="object-contain"
                      />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{producto.nombre}</h3>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-2xl font-bold">${producto.precio}</span>
                    <span className="text-lg text-gray-400 line-through">${producto.precioOriginal}</span>
                  </div>
                  <p className="text-sm text-red-400 mb-4">Solo quedan {producto.stock} unidades</p>
                  <Button className="w-full bg-white text-gray-900 hover:bg-gray-100 font-medium">Comprar Ahora</Button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Productos por Categoría */}
        <section className="w-full py-20 bg-white">
          <div className="container max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Explora por Categoría</h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Encuentra el dispositivo perfecto para tu estilo de vida
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* iPhone */}
              <Link href="/productos/iphone" className="group">
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-3xl p-12 text-center hover:shadow-2xl transition-all duration-300 group-hover:scale-[1.02]">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">iPhone</h3>
                      <p className="text-lg text-gray-600">Desde $699</p>
                      <p className="text-sm text-gray-500 mt-2">Financiamiento disponible desde $29/mes</p>
                    </div>
                    <div className="flex gap-4 justify-center">
                      <Button variant="link" className="text-blue-600 font-medium p-0 group-hover:underline">
                        Comprar <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                      <Button variant="link" className="text-blue-600 font-medium p-0 group-hover:underline">
                        Comparar modelos <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                    <div className="relative h-[300px] pt-4">
                      <Image
                        src="/placeholder.svg?height=300&width=250&text=iPhone+Collection"
                        alt="iPhone Collection"
                        fill
                        className="object-contain group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  </div>
                </div>
              </Link>

              {/* Mac */}
              <Link href="/productos/mac" className="group">
                <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl p-12 text-center text-white hover:shadow-2xl transition-all duration-300 group-hover:scale-[1.02]">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-3xl md:text-4xl font-bold mb-3">Mac</h3>
                      <p className="text-lg text-gray-300">Desde $1,099</p>
                      <p className="text-sm text-gray-400 mt-2">Potencia profesional para crear sin límites</p>
                    </div>
                    <div className="flex gap-4 justify-center">
                      <Button variant="link" className="text-blue-400 font-medium p-0 group-hover:underline">
                        Comprar <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                      <Button variant="link" className="text-blue-400 font-medium p-0 group-hover:underline">
                        Ver modelos <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                    <div className="relative h-[300px] pt-4">
                      <Image
                        src="/placeholder.svg?height=300&width=400&text=MacBook+Collection"
                        alt="Mac Collection"
                        fill
                        className="object-contain group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  </div>
                </div>
              </Link>

              {/* iPad */}
              <Link href="/productos/ipad" className="group">
                <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-3xl p-12 text-center hover:shadow-2xl transition-all duration-300 group-hover:scale-[1.02]">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">iPad</h3>
                      <p className="text-lg text-gray-600">Desde $329</p>
                      <p className="text-sm text-gray-500 mt-2">Creatividad y productividad en tus manos</p>
                    </div>
                    <div className="flex gap-4 justify-center">
                      <Button variant="link" className="text-blue-600 font-medium p-0 group-hover:underline">
                        Comprar <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                      <Button variant="link" className="text-blue-600 font-medium p-0 group-hover:underline">
                        Comparar <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                    <div className="relative h-[300px] pt-4">
                      <Image
                        src="/placeholder.svg?height=300&width=250&text=iPad+Collection"
                        alt="iPad Collection"
                        fill
                        className="object-contain group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  </div>
                </div>
              </Link>

              {/* Accesorios */}
              <Link href="/productos/accesorios" className="group">
                <div className="bg-gradient-to-br from-purple-50 to-pink-100 rounded-3xl p-12 text-center hover:shadow-2xl transition-all duration-300 group-hover:scale-[1.02]">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">Accesorios</h3>
                      <p className="text-lg text-gray-600">Desde $29</p>
                      <p className="text-sm text-gray-500 mt-2">Complementa tu experiencia Apple</p>
                    </div>
                    <div className="flex gap-4 justify-center">
                      <Button variant="link" className="text-blue-600 font-medium p-0 group-hover:underline">
                        Explorar <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                      <Button variant="link" className="text-blue-600 font-medium p-0 group-hover:underline">
                        Ofertas <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                    <div className="relative h-[300px] pt-4">
                      <Image
                        src="/placeholder.svg?height=300&width=350&text=Accesorios+Collection"
                        alt="Accesorios Collection"
                        fill
                        className="object-contain group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </section>

        {/* Testimonios y Confianza */}
        <section className="w-full py-20 bg-gray-50">
          <div className="container max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Más de 50,000 clientes satisfechos</h2>
              <div className="flex justify-center items-center gap-2 mb-8">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-6 w-6 text-yellow-400 fill-yellow-400" />
                ))}
                <span className="text-lg font-semibold text-gray-700 ml-2">4.9/5</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  nombre: "María González",
                  comentario:
                    "Increíble servicio. Mi iPhone llegó al día siguiente y funciona perfecto. Definitivamente volveré a comprar aquí.",
                  producto: "iPhone 15 Pro",
                  rating: 5,
                },
                {
                  nombre: "Carlos Ruiz",
                  comentario:
                    "La mejor experiencia de compra online que he tenido. Proceso súper fácil y atención al cliente excepcional.",
                  producto: "MacBook Pro M3",
                  rating: 5,
                },
                {
                  nombre: "Ana Martínez",
                  comentario:
                    "Precios competitivos y productos originales. El iPad que compré superó mis expectativas. 100% recomendado.",
                  producto: "iPad Air",
                  rating: 5,
                },
              ].map((testimonio, index) => (
                <div key={index} className="bg-white rounded-2xl p-6 shadow-lg">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonio.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{testimonio.comentario}"</p>
                  <div>
                    <p className="font-semibold text-gray-900">{testimonio.nombre}</p>
                    <p className="text-sm text-gray-500">Compró: {testimonio.producto}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Final */}
        <section className="w-full py-20 bg-gradient-to-r from-gray-900 to-gray-800 text-white">
          <div className="container max-w-4xl mx-auto px-6 text-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h2 className="text-4xl md:text-5xl font-bold">¿Listo para tu próximo dispositivo?</h2>
                <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                  Únete a miles de clientes que ya disfrutan de la mejor tecnología con garantía y soporte premium.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-white text-gray-900 hover:bg-gray-100 px-8 py-4 text-lg font-medium rounded-full"
                >
                  Explorar Productos
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-2 border-white text-white hover:bg-white hover:text-gray-900 px-8 py-4 text-lg font-medium rounded-full"
                >
                  Hablar con un Experto
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full bg-gray-50 border-t border-gray-200">
        <div className="container max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            <div className="col-span-2 md:col-span-1">
              <h3 className="font-semibold text-gray-900 mb-4">Productos</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    iPhone
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Mac
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    iPad
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Accesorios
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Soporte</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Centro de Ayuda
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Garantía
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Reparaciones
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Empresa</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Acerca de
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Contacto
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Ubicaciones
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Legal</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Privacidad
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Términos
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Devoluciones
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Síguenos</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Instagram
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Facebook
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-900 transition-colors">
                    Twitter
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-12 pt-8 text-center">
            <p className="text-sm text-gray-500">© 2025 TechPremium. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
