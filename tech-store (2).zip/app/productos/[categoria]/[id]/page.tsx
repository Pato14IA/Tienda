import Link from "next/link"
import Image from "next/image"
import { Star, Truck, Shield, CreditCard } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ProductoDetalle({ params }: { params: { categoria: string; id: string } }) {
  const { categoria, id } = params
  const categoriaTitle = categoria.charAt(0).toUpperCase() + categoria.slice(1)

  // Datos de ejemplo
  const producto = {
    id: Number.parseInt(id),
    nombre: `${categoria === "celulares" ? "Smartphone Pro Max" : categoria === "computadoras" ? 'Laptop Ultra 16"' : categoria === "ipads" ? "Tablet Pro" : "Smartwatch Ultra"} ${id}`,
    precio: 1199,
    descripcion: "Diseño premium con tecnología de vanguardia y rendimiento excepcional.",
    caracteristicas: [
      "Pantalla Super AMOLED de alta resolución",
      "Procesador de última generación",
      "Sistema de cámaras profesional",
      "Batería de larga duración",
      "Resistente al agua y polvo",
      "Sistema operativo optimizado",
    ],
    especificaciones: {
      Pantalla: '6.7" Super Retina XDR OLED, 120Hz ProMotion',
      Chip: "A17 Pro con Neural Engine de 16 núcleos",
      Almacenamiento: "128GB, 256GB, 512GB, 1TB",
      Cámaras: "Principal 48MP, Ultra gran angular 12MP, Teleobjetivo 12MP",
      "Cámara frontal": "TrueDepth 12MP",
      Batería: "Hasta 29 horas de reproducción de video",
      "Sistema operativo": "iOS 17",
      Dimensiones: "159.9 x 76.7 x 8.25 mm",
      Peso: "221 g",
      Conectividad: "5G, Wi-Fi 6E, Bluetooth 5.3",
    },
    colores: [
      { nombre: "Titanio Natural", clase: "bg-amber-100" },
      { nombre: "Titanio Azul", clase: "bg-blue-200" },
      { nombre: "Titanio Blanco", clase: "bg-gray-100" },
      { nombre: "Titanio Negro", clase: "bg-gray-800" },
    ],
    capacidades: ["128GB", "256GB", "512GB", "1TB"],
    precios: { "128GB": 1199, "256GB": 1299, "512GB": 1499, "1TB": 1699 },
    calificacion: 4.9,
    opiniones: 2847,
    imagen: `/placeholder.svg?height=500&width=500&text=${categoriaTitle}+${id}`,
    imagenes: [
      `/placeholder.svg?height=500&width=500&text=${categoriaTitle}+${id}+Front`,
      `/placeholder.svg?height=500&width=500&text=${categoriaTitle}+${id}+Back`,
      `/placeholder.svg?height=500&width=500&text=${categoriaTitle}+${id}+Side`,
      `/placeholder.svg?height=500&width=500&text=${categoriaTitle}+${id}+Colors`,
    ],
  }

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <header className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-xl border-b border-gray-100">
        <div className="container flex h-16 items-center justify-between max-w-6xl mx-auto px-6">
          <Link href="/" className="flex items-center gap-2 font-semibold text-xl text-black">
            <div className="h-8 w-8 bg-black rounded-lg flex items-center justify-center">
              <svg className="h-4 w-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <rect width="14" height="20" x="5" y="2" rx="2" ry="2" />
                <path d="M12 18h.01" />
              </svg>
            </div>
            <span>TechStore</span>
          </Link>
          <nav className="hidden md:flex gap-8">
            <Link
              href="/productos/celulares"
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors"
            >
              Celulares
            </Link>
            <Link
              href="/productos/computadoras"
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors"
            >
              Computadoras
            </Link>
            <Link
              href="/productos/ipads"
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors"
            >
              iPads
            </Link>
            <Link
              href="/productos/accesorios"
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors"
            >
              Accesorios
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <div className="container max-w-6xl mx-auto px-6 py-12">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 mb-12">
            <Link href="/" className="text-sm text-gray-500 hover:text-black transition-colors">
              Inicio
            </Link>
            <span className="text-sm text-gray-400">/</span>
            <Link href={`/productos/${categoria}`} className="text-sm text-gray-500 hover:text-black transition-colors">
              {categoriaTitle === "celulares"
                ? "iPhone"
                : categoriaTitle === "laptops"
                  ? "Mac"
                  : categoriaTitle === "accesorios"
                    ? "AirPods"
                    : "Apple Watch"}
            </Link>
            <span className="text-sm text-gray-400">/</span>
            <span className="text-sm font-medium text-black">{producto.nombre}</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
            {/* Product Images */}
            <div className="space-y-6">
              <div className="bg-gray-50 rounded-3xl p-12">
                <div className="relative h-[500px]">
                  <Image
                    src={producto.imagen || "/placeholder.svg"}
                    alt={producto.nombre}
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
              <div className="grid grid-cols-4 gap-4">
                {producto.imagenes.map((img, index) => (
                  <div
                    key={index}
                    className="bg-gray-50 rounded-xl p-4 cursor-pointer hover:bg-gray-100 transition-colors"
                  >
                    <div className="relative h-[80px]">
                      <Image
                        src={img || "/placeholder.svg"}
                        alt={`${producto.nombre} - Vista ${index + 1}`}
                        fill
                        className="object-contain"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-8">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold text-black mb-4">{producto.nombre}</h1>
                <div className="flex items-center gap-3 mb-6">
                  <div className="flex items-center">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(producto.calificacion)
                            ? "text-blue-500 fill-blue-500"
                            : i < producto.calificacion
                              ? "text-blue-500 fill-blue-500 opacity-50"
                              : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600 font-light">
                    {producto.calificacion} ({producto.opiniones.toLocaleString()} reseñas)
                  </span>
                </div>
                <p className="text-xl text-gray-600 font-light leading-relaxed mb-8">{producto.descripcion}</p>
              </div>

              {/* Color Selection */}
              <div>
                <h3 className="font-semibold text-black mb-4">Color — Titanio Natural</h3>
                <div className="flex gap-3">
                  {producto.colores.map((color) => (
                    <button
                      key={color.nombre}
                      className={`w-12 h-12 rounded-full border-2 border-gray-300 hover:border-black transition-colors ${color.clase}`}
                      title={color.nombre}
                    />
                  ))}
                </div>
              </div>

              {/* Storage Selection */}
              <div>
                <h3 className="font-semibold text-black mb-4">Capacidad</h3>
                <div className="grid grid-cols-2 gap-3">
                  {producto.capacidades.map((capacidad) => (
                    <button
                      key={capacidad}
                      className="p-4 border border-gray-300 rounded-xl text-center hover:border-black transition-colors"
                    >
                      <div className="font-medium text-black">{capacidad}</div>
                      <div className="text-sm text-gray-600 font-light">
                        ${producto.precios[capacidad as keyof typeof producto.precios]?.toLocaleString()}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Price and Purchase */}
              <div className="space-y-6">
                <div>
                  <span className="text-3xl font-bold text-black">Desde ${producto.precio.toLocaleString()}</span>
                  <p className="text-sm text-gray-600 font-light mt-1">
                    O $49.95/mes durante 24 meses antes de intercambio*
                  </p>
                </div>

                <div className="space-y-3">
                  <Button
                    size="lg"
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white rounded-full font-medium py-4"
                  >
                    Añadir a la bolsa
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="w-full border-blue-500 text-blue-500 hover:bg-blue-50 rounded-full font-medium py-4"
                  >
                    Añadir a favoritos
                  </Button>
                </div>

                <div className="grid grid-cols-1 gap-4 pt-6">
                  <div className="flex items-start gap-3">
                    <Truck className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="font-medium text-black">Envío gratuito</p>
                      <p className="text-sm text-gray-600 font-light">Recíbelo entre el mar, 28 ene y el jue, 30 ene</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="font-medium text-black">AppleCare+</p>
                      <p className="text-sm text-gray-600 font-light">Protege tu iPhone con cobertura adicional</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CreditCard className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="font-medium text-black">Financiación disponible</p>
                      <p className="text-sm text-gray-600 font-light">Paga a plazos sin intereses</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Product Details Tabs */}
          <Tabs defaultValue="descripcion" className="mb-20">
            <TabsList className="grid w-full grid-cols-3 bg-gray-100 rounded-full p-1">
              <TabsTrigger value="descripcion" className="rounded-full font-medium">
                Descripción
              </TabsTrigger>
              <TabsTrigger value="especificaciones" className="rounded-full font-medium">
                Especificaciones
              </TabsTrigger>
              <TabsTrigger value="opiniones" className="rounded-full font-medium">
                Reseñas
              </TabsTrigger>
            </TabsList>
            <TabsContent value="descripcion" className="mt-8">
              <div className="max-w-4xl">
                <h3 className="text-2xl font-bold text-black mb-6">Forjado en titanio</h3>
                <p className="text-lg text-gray-600 font-light leading-relaxed mb-8">
                  El iPhone 15 Pro cuenta con un diseño de titanio resistente y ligero con una parte trasera de vidrio
                  mate texturizado. La parte frontal cuenta con Ceramic Shield, que es más resistente que cualquier
                  vidrio de smartphone.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="font-semibold text-black mb-3">Características principales</h4>
                    <ul className="space-y-2">
                      {producto.caracteristicas.map((caracteristica, index) => (
                        <li key={index} className="text-gray-600 font-light flex items-start">
                          <span className="text-blue-500 mr-2">•</span>
                          {caracteristica}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="bg-gray-50 rounded-2xl p-6">
                    <h4 className="font-semibold text-black mb-3">En la caja</h4>
                    <ul className="space-y-2 text-gray-600 font-light">
                      <li>iPhone 15 Pro</li>
                      <li>Cable de USB-C a USB-C</li>
                      <li>Documentación</li>
                    </ul>
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="especificaciones" className="mt-8">
              <div className="max-w-4xl">
                <h3 className="text-2xl font-bold text-black mb-6">Especificaciones técnicas</h3>
                <div className="space-y-6">
                  {Object.entries(producto.especificaciones).map(([key, value]) => (
                    <div key={key} className="flex flex-col md:flex-row md:items-center py-4 border-b border-gray-100">
                      <div className="md:w-1/3">
                        <span className="font-medium text-black">{key}</span>
                      </div>
                      <div className="md:w-2/3">
                        <span className="text-gray-600 font-light">{value}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
            <TabsContent value="opiniones" className="mt-8">
              <div className="max-w-4xl">
                <div className="flex items-center gap-8 mb-8">
                  <div className="text-center">
                    <div className="text-5xl font-bold text-black mb-2">{producto.calificacion}</div>
                    <div className="flex justify-center mb-2">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < Math.floor(producto.calificacion) ? "text-blue-500 fill-blue-500" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-sm text-gray-600 font-light">
                      Basado en {producto.opiniones.toLocaleString()} reseñas
                    </div>
                  </div>
                  <div className="flex-1 space-y-2">
                    {[5, 4, 3, 2, 1].map((rating) => (
                      <div key={rating} className="flex items-center gap-3">
                        <div className="text-sm font-medium text-black w-3">{rating}</div>
                        <Star className="h-4 w-4 text-blue-500 fill-blue-500" />
                        <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500 rounded-full transition-all"
                            style={{
                              width: `${rating === 5 ? 85 : rating === 4 ? 12 : rating === 3 ? 2 : rating === 2 ? 1 : 0}%`,
                            }}
                          />
                        </div>
                        <div className="text-sm text-gray-600 font-light w-8">
                          {rating === 5
                            ? "85%"
                            : rating === 4
                              ? "12%"
                              : rating === 3
                                ? "2%"
                                : rating === 2
                                  ? "1%"
                                  : "0%"}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <Button variant="outline" className="rounded-full font-medium">
                  Leer todas las reseñas
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <footer className="w-full bg-gray-50 border-t border-gray-200">
        <div className="container max-w-6xl mx-auto px-6 py-12">
          <div className="text-center">
            <p className="text-sm text-gray-500">© 2025 TechStore. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
