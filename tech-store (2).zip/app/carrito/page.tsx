import Link from "next/link"
import Image from "next/image"
import { ChevronLeft, Trash2, CreditCard, ShoppingBag } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

export default function Carrito() {
  // Datos de ejemplo para el carrito
  const productosCarrito = [
    {
      id: 1,
      nombre: "Smartphone Premium X",
      precio: 999.99,
      cantidad: 1,
      imagen: "/placeholder.svg?height=100&width=100&text=Smartphone+X",
    },
    {
      id: 2,
      nombre: "Auriculares Inalámbricos Pro",
      precio: 149.99,
      cantidad: 2,
      imagen: "/placeholder.svg?height=100&width=100&text=Auriculares",
    },
  ]

  const subtotal = productosCarrito.reduce((total, producto) => total + producto.precio * producto.cantidad, 0)
  const envio = 0 // Envío gratis
  const total = subtotal + envio

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <rect width="14" height="20" x="5" y="2" rx="2" ry="2" />
              <path d="M12 18h.01" />
            </svg>
            <span>TechStore</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/productos/celulares" className="text-sm font-medium hover:underline underline-offset-4">
              Celulares
            </Link>
            <Link href="/productos/computadoras" className="text-sm font-medium hover:underline underline-offset-4">
              Computadoras
            </Link>
            <Link href="/productos/ipads" className="text-sm font-medium hover:underline underline-offset-4">
              iPads
            </Link>
            <Link href="/productos/accesorios" className="text-sm font-medium hover:underline underline-offset-4">
              Accesorios
            </Link>
          </nav>
          <Button variant="outline" size="icon" className="md:hidden">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <div className="container px-4 md:px-6 py-8">
          <div className="flex items-center gap-2 mb-8">
            <Link
              href="/"
              className="flex items-center text-sm text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Continuar Comprando
            </Link>
          </div>

          <h1 className="text-3xl font-bold mb-8">Tu Carrito</h1>

          {productosCarrito.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="rounded-lg border overflow-hidden">
                  <div className="bg-muted p-4">
                    <div className="grid grid-cols-12 gap-4 text-sm font-medium">
                      <div className="col-span-6">Producto</div>
                      <div className="col-span-2 text-center">Precio</div>
                      <div className="col-span-2 text-center">Cantidad</div>
                      <div className="col-span-2 text-right">Total</div>
                    </div>
                  </div>

                  {productosCarrito.map((producto) => (
                    <div key={producto.id} className="p-4 border-t">
                      <div className="grid grid-cols-12 gap-4 items-center">
                        <div className="col-span-6">
                          <div className="flex items-center gap-4">
                            <div className="relative h-16 w-16 rounded border overflow-hidden">
                              <Image
                                src={producto.imagen || "/placeholder.svg"}
                                alt={producto.nombre}
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <h3 className="font-medium">{producto.nombre}</h3>
                              <button className="text-sm text-red-500 flex items-center gap-1 mt-1">
                                <Trash2 className="h-3 w-3" />
                                Eliminar
                              </button>
                            </div>
                          </div>
                        </div>
                        <div className="col-span-2 text-center">${producto.precio.toFixed(2)}</div>
                        <div className="col-span-2 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <Button variant="outline" size="icon" className="h-8 w-8">
                              -
                            </Button>
                            <span className="w-8 text-center">{producto.cantidad}</span>
                            <Button variant="outline" size="icon" className="h-8 w-8">
                              +
                            </Button>
                          </div>
                        </div>
                        <div className="col-span-2 text-right font-medium">
                          ${(producto.precio * producto.cantidad).toFixed(2)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="flex gap-2">
                      <Input placeholder="Código de cupón" className="flex-1" />
                      <Button variant="outline">Aplicar</Button>
                    </div>
                  </div>
                  <Button variant="outline" className="flex items-center gap-2">
                    <ShoppingBag className="h-4 w-4" />
                    Continuar Comprando
                  </Button>
                </div>
              </div>

              <div className="lg:col-span-1">
                <div className="rounded-lg border p-4">
                  <h2 className="text-lg font-bold mb-4">Resumen del Pedido</h2>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Envío</span>
                      <span>{envio === 0 ? "Gratis" : `$${envio.toFixed(2)}`}</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>

                  <Button className="w-full mt-6 flex items-center gap-2">
                    <CreditCard className="h-4 w-4" />
                    Proceder al Pago
                  </Button>

                  <div className="mt-4 text-xs text-gray-500">
                    <p>Aceptamos múltiples métodos de pago:</p>
                    <div className="flex gap-2 mt-2">
                      <div className="h-6 w-10 bg-gray-200 rounded"></div>
                      <div className="h-6 w-10 bg-gray-200 rounded"></div>
                      <div className="h-6 w-10 bg-gray-200 rounded"></div>
                      <div className="h-6 w-10 bg-gray-200 rounded"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-muted mb-4">
                <ShoppingBag className="h-10 w-10 text-muted-foreground" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Tu carrito está vacío</h2>
              <p className="text-muted-foreground mb-6">Parece que aún no has añadido productos a tu carrito</p>
              <Button asChild>
                <Link href="/">Explorar Productos</Link>
              </Button>
            </div>
          )}
        </div>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-center gap-4 md:h-24 md:flex-row md:justify-between">
          <p className="text-center text-sm leading-loose text-gray-500 md:text-left dark:text-gray-400">
            © 2025 TechStore. Todos los derechos reservados.
          </p>
          <div className="flex gap-4">
            <Link href="/terminos" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
              Términos
            </Link>
            <Link href="/privacidad" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
              Privacidad
            </Link>
            <Link href="/contacto" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
              Contacto
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
