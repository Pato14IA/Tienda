import Link from "next/link"
import Image from "next/image"
import { ChevronLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

export default function ProductosCategoria({ params }: { params: { categoria: string } }) {
  const categoria = params.categoria

  const getTitleForCategory = (categoria: string) => {
    switch (categoria) {
      case "celulares":
        return "Celulares"
      case "computadoras":
        return "Computadoras"
      case "ipads":
        return "iPads"
      case "accesorios":
        return "Accesorios"
      default:
        return categoria.charAt(0).toUpperCase() + categoria.slice(1)
    }
  }

  const categoriaTitle = getTitleForCategory(categoria)

  // Datos de ejemplo
  const productos = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    nombre: `${categoriaTitle === "Celulares" ? "iPhone 15" : categoriaTitle === "Computadoras" ? "MacBook Pro" : categoriaTitle === "Accesorios" ? "AirPods Pro" : "Apple Watch"} ${i + 1}`,
    precio: 999 + i * 200,
    precioAnterior: 1199 + i * 200,
    descripcion: "Diseño premium con tecnología avanzada",
    imagen: `/placeholder.svg?height=300&width=300&text=${categoriaTitle}+${i + 1}`,
    colores: ["Titanio Natural", "Titanio Azul", "Titanio Blanco", "Titanio Negro"],
  }))

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <header className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-xl border-b border-gray-100">
        <div className="container flex h-16 items-center justify-between max-w-6xl mx-auto px-6">
          <Link href="/" className="flex items-center gap-2 font-semibold text-xl text-black">
            <div className="h-8 w-8 bg-black rounded-lg flex items-center justify-center">
              <svg className="h-4 w-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <rect width="14" height="20" x="5" y="2" rx="2" ry="2" />
                <path d="M12 18h.01" />
              </svg>
            </div>
            <span>TechStore</span>
          </Link>
          <nav className="hidden md:flex gap-8">
            <Link
              href="/productos/celulares"
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors"
            >
              Celulares
            </Link>
            <Link
              href="/productos/computadoras"
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors"
            >
              Computadoras
            </Link>
            <Link
              href="/productos/ipads"
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors"
            >
              iPads
            </Link>
            <Link
              href="/productos/accesorios"
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors"
            >
              Accesorios
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <div className="container max-w-6xl mx-auto px-6 py-12">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 mb-12">
            <Link href="/" className="flex items-center text-sm text-gray-500 hover:text-black transition-colors">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Inicio
            </Link>
            <span className="text-sm text-gray-400">/</span>
            <span className="text-sm font-medium text-black">{categoriaTitle}</span>
          </div>

          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-black mb-4">{categoriaTitle}</h1>
            <p className="text-xl text-gray-600 font-light max-w-2xl mx-auto">
              {categoria === "celulares"
                ? "Conecta con el mundo de manera inteligente."
                : categoria === "computadoras"
                  ? "Potencia y rendimiento para cada necesidad."
                  : categoria === "ipads"
                    ? "Creatividad y productividad en tus manos."
                    : "Complementa tu experiencia tecnológica."}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
            {/* Filters Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-gray-50 rounded-2xl p-6 space-y-8">
                <div>
                  <h3 className="text-lg font-semibold text-black mb-4">Filtros</h3>
                </div>

                <div>
                  <h4 className="font-medium text-black mb-3">Precio</h4>
                  <div className="space-y-3">
                    {["Menos de $1,000", "$1,000 - $1,500", "$1,500 - $2,000", "Más de $2,000"].map((precio) => (
                      <div key={precio} className="flex items-center space-x-3">
                        <Checkbox id={precio} className="rounded" />
                        <label htmlFor={precio} className="text-sm text-gray-600 font-light">
                          {precio}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-black mb-3">Color</h4>
                  <div className="space-y-3">
                    {["Titanio Natural", "Titanio Azul", "Titanio Blanco", "Titanio Negro"].map((color) => (
                      <div key={color} className="flex items-center space-x-3">
                        <Checkbox id={color} className="rounded" />
                        <label htmlFor={color} className="text-sm text-gray-600 font-light">
                          {color}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-black mb-3">Capacidad</h4>
                  <div className="space-y-3">
                    {["128GB", "256GB", "512GB", "1TB"].map((capacidad) => (
                      <div key={capacidad} className="flex items-center space-x-3">
                        <Checkbox id={capacidad} className="rounded" />
                        <label htmlFor={capacidad} className="text-sm text-gray-600 font-light">
                          {capacidad}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Products Grid */}
            <div className="lg:col-span-3 space-y-8">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <p className="text-gray-600 font-light">{productos.length} productos</p>
                <div className="flex items-center gap-4">
                  <Select>
                    <SelectTrigger className="w-[200px] rounded-full border-gray-300">
                      <SelectValue placeholder="Ordenar por" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevancia">Más relevantes</SelectItem>
                      <SelectItem value="precio-asc">Precio: menor a mayor</SelectItem>
                      <SelectItem value="precio-desc">Precio: mayor a menor</SelectItem>
                      <SelectItem value="nuevo">Más recientes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                {productos.map((producto) => (
                  <div key={producto.id} className="group cursor-pointer">
                    <div className="bg-gray-50 rounded-2xl p-8 mb-4 group-hover:bg-gray-100 transition-colors">
                      <div className="relative h-[250px] mb-4">
                        <Image
                          src={producto.imagen || "/placeholder.svg"}
                          alt={producto.nombre}
                          fill
                          className="object-contain"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-semibold text-lg text-black group-hover:text-blue-500 transition-colors">
                        {producto.nombre}
                      </h3>
                      <p className="text-gray-600 font-light text-sm">{producto.descripcion}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold text-black">
                          Desde ${producto.precio.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex gap-1 mt-2">
                        {producto.colores.slice(0, 4).map((color, index) => (
                          <div
                            key={color}
                            className={`w-4 h-4 rounded-full border border-gray-300 ${
                              index === 0
                                ? "bg-amber-100"
                                : index === 1
                                  ? "bg-blue-200"
                                  : index === 2
                                    ? "bg-gray-100"
                                    : "bg-gray-800"
                            }`}
                          />
                        ))}
                      </div>
                      <div className="pt-2">
                        <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white rounded-full font-medium">
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="w-full bg-gray-50 border-t border-gray-200 mt-20">
        <div className="container max-w-6xl mx-auto px-6 py-12">
          <div className="text-center">
            <p className="text-sm text-gray-500">© 2025 TechStore. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
