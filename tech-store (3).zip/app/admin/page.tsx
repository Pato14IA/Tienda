"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Plus, Edit, Trash2, Upload, Save, Eye, Package, DollarSign, TrendingUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"

export default function AdminPanel() {
  const [productos, setProductos] = useState([
    {
      id: 1,
      nombre: "iPhone 15 Pro Max",
      precio: 1199,
      precioOriginal: 1299,
      categoria: "iphone",
      descripcion: "El iPhone más avanzado con titanio y chip A17 Pro",
      imagen: "/placeholder.svg?height=300&width=300&text=iPhone+15+Pro+Max",
      stock: 25,
      destacado: true,
      oferta: true,
      colores: ["Titanio Natural", "Titanio Azul", "Titanio Blanco", "Titanio Negro"],
      capacidades: ["128GB", "256GB", "512GB", "1TB"],
    },
    {
      id: 2,
      nombre: 'MacBook Pro 16" M3',
      precio: 2499,
      precioOriginal: 2699,
      categoria: "mac",
      descripcion: "Potencia profesional con chip M3 para creativos",
      imagen: "/placeholder.svg?height=300&width=300&text=MacBook+Pro+M3",
      stock: 15,
      destacado: true,
      oferta: false,
      colores: ["Gris Espacial", "Plata"],
      capacidades: ["512GB", "1TB", "2TB"],
    },
    {
      id: 3,
      nombre: 'iPad Pro 12.9"',
      precio: 1099,
      precioOriginal: 1199,
      categoria: "ipad",
      descripcion: "Creatividad sin límites con chip M2",
      imagen: "/placeholder.svg?height=300&width=300&text=iPad+Pro+12.9",
      stock: 30,
      destacado: false,
      oferta: true,
      colores: ["Gris Espacial", "Plata"],
      capacidades: ["128GB", "256GB", "512GB", "1TB"],
    },
  ])

  const [nuevoProducto, setNuevoProducto] = useState({
    nombre: "",
    precio: "",
    precioOriginal: "",
    categoria: "iphone",
    descripcion: "",
    imagen: "",
    stock: "",
    destacado: false,
    oferta: false,
    colores: "",
    capacidades: "",
  })

  const [editandoProducto, setEditandoProducto] = useState(null)
  const [configuracion, setConfiguracion] = useState({
    nombreTienda: "TechPremium",
    eslogan: "Forjado en titanio. Potenciado por A17 Pro.",
    email: "contacto@techpremium.com",
    telefono: "+1 234 567 8900",
    direccion: "123 Tech Street, Silicon Valley",
    horarios: "Lun-Vie: 9AM-8PM, Sáb-Dom: 10AM-6PM",
  })

  // Verificar autenticación
  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth")
    if (!isAuth) {
      window.location.href = "/admin/login"
    }
  }, [])

  const agregarProducto = () => {
    if (nuevoProducto.nombre && nuevoProducto.precio) {
      const producto = {
        id: productos.length + 1,
        nombre: nuevoProducto.nombre,
        precio: Number.parseFloat(nuevoProducto.precio),
        precioOriginal: Number.parseFloat(nuevoProducto.precioOriginal) || Number.parseFloat(nuevoProducto.precio),
        categoria: nuevoProducto.categoria,
        descripcion: nuevoProducto.descripcion,
        imagen:
          nuevoProducto.imagen ||
          "/placeholder.svg?height=300&width=300&text=" + nuevoProducto.nombre.replace(/\s+/g, "+"),
        stock: Number.parseInt(nuevoProducto.stock) || 0,
        destacado: nuevoProducto.destacado,
        oferta: nuevoProducto.oferta,
        colores: nuevoProducto.colores.split(",").map((c) => c.trim()),
        capacidades: nuevoProducto.capacidades.split(",").map((c) => c.trim()),
      }
      setProductos([...productos, producto])
      setNuevoProducto({
        nombre: "",
        precio: "",
        precioOriginal: "",
        categoria: "iphone",
        descripcion: "",
        imagen: "",
        stock: "",
        destacado: false,
        oferta: false,
        colores: "",
        capacidades: "",
      })
    }
  }

  const eliminarProducto = (id) => {
    setProductos(productos.filter((p) => p.id !== id))
  }

  const editarProducto = (producto) => {
    setEditandoProducto({
      ...producto,
      colores: producto.colores.join(", "),
      capacidades: producto.capacidades.join(", "),
    })
  }

  const guardarEdicion = () => {
    if (editandoProducto) {
      const productosActualizados = productos.map((p) =>
        p.id === editandoProducto.id
          ? {
              ...editandoProducto,
              precio: Number.parseFloat(editandoProducto.precio),
              precioOriginal: Number.parseFloat(editandoProducto.precioOriginal),
              stock: Number.parseInt(editandoProducto.stock),
              colores: editandoProducto.colores.split(",").map((c) => c.trim()),
              capacidades: editandoProducto.capacidades.split(",").map((c) => c.trim()),
            }
          : p,
      )
      setProductos(productosActualizados)
      setEditandoProducto(null)
    }
  }

  const estadisticas = {
    totalProductos: productos.length,
    stockTotal: productos.reduce((sum, p) => sum + p.stock, 0),
    valorInventario: productos.reduce((sum, p) => sum + p.precio * p.stock, 0),
    productosDestacados: productos.filter((p) => p.destacado).length,
    productosEnOferta: productos.filter((p) => p.oferta).length,
    stockBajo: productos.filter((p) => p.stock < 10).length,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Admin */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Panel de Administración</h1>
              <p className="text-gray-600">Gestiona tu tienda {configuracion.nombreTienda}</p>
            </div>
            <div className="flex gap-3">
              <Button asChild variant="outline" className="border-gray-300">
                <Link href="/" target="_blank">
                  <Eye className="h-4 w-4 mr-2" />
                  Ver Tienda
                </Link>
              </Button>
              <Button
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => alert("Cambios guardados exitosamente!")}
              >
                <Save className="h-4 w-4 mr-2" />
                Guardar Todo
              </Button>
              <Button
                variant="outline"
                className="text-red-600 border-red-300 hover:bg-red-50"
                onClick={() => {
                  localStorage.removeItem("adminAuth")
                  window.location.href = "/admin/login"
                }}
              >
                Cerrar Sesión
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-white border border-gray-200">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="productos" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Productos
            </TabsTrigger>
            <TabsTrigger
              value="inventario"
              className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700"
            >
              Inventario
            </TabsTrigger>
            <TabsTrigger
              value="configuracion"
              className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700"
            >
              Configuración
            </TabsTrigger>
            <TabsTrigger value="imagenes" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Imágenes
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-600">Total Productos</p>
                      <p className="text-3xl font-bold text-blue-900">{estadisticas.totalProductos}</p>
                    </div>
                    <Package className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-green-200 bg-green-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600">Stock Total</p>
                      <p className="text-3xl font-bold text-green-900">{estadisticas.stockTotal}</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-200 bg-purple-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-purple-600">Valor Inventario</p>
                      <p className="text-3xl font-bold text-purple-900">
                        ${estadisticas.valorInventario.toLocaleString()}
                      </p>
                    </div>
                    <DollarSign className="h-8 w-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-orange-200 bg-orange-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-orange-600">Stock Bajo</p>
                      <p className="text-3xl font-bold text-orange-900">{estadisticas.stockBajo}</p>
                    </div>
                    <Package className="h-8 w-8 text-orange-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Productos Destacados */}
            <Card>
              <CardHeader>
                <CardTitle>Productos Más Vendidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {productos.slice(0, 3).map((producto) => (
                    <div key={producto.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="relative h-12 w-12 bg-white rounded-lg overflow-hidden">
                          <Image
                            src={producto.imagen || "/placeholder.svg"}
                            alt={producto.nombre}
                            fill
                            className="object-contain"
                          />
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{producto.nombre}</p>
                          <p className="text-sm text-gray-600">${producto.precio.toLocaleString()}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">Stock: {producto.stock}</p>
                        <p className="text-sm text-gray-600">Categoría: {producto.categoria}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Gestión de Productos */}
          <TabsContent value="productos" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Gestión de Productos</h2>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 mr-2" />
                Nuevo Producto
              </Button>
            </div>

            {/* Formulario Nuevo/Editar Producto */}
            <Card>
              <CardHeader>
                <CardTitle>{editandoProducto ? "Editar Producto" : "Agregar Nuevo Producto"}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="nombre">Nombre del Producto *</Label>
                    <Input
                      id="nombre"
                      value={editandoProducto ? editandoProducto.nombre : nuevoProducto.nombre}
                      onChange={(e) =>
                        editandoProducto
                          ? setEditandoProducto({ ...editandoProducto, nombre: e.target.value })
                          : setNuevoProducto({ ...nuevoProducto, nombre: e.target.value })
                      }
                      placeholder="Ej: iPhone 15 Pro Max"
                    />
                  </div>

                  <div>
                    <Label htmlFor="precio">Precio Actual ($) *</Label>
                    <Input
                      id="precio"
                      type="number"
                      value={editandoProducto ? editandoProducto.precio : nuevoProducto.precio}
                      onChange={(e) =>
                        editandoProducto
                          ? setEditandoProducto({ ...editandoProducto, precio: e.target.value })
                          : setNuevoProducto({ ...nuevoProducto, precio: e.target.value })
                      }
                      placeholder="1199"
                    />
                  </div>

                  <div>
                    <Label htmlFor="precioOriginal">Precio Original ($)</Label>
                    <Input
                      id="precioOriginal"
                      type="number"
                      value={editandoProducto ? editandoProducto.precioOriginal : nuevoProducto.precioOriginal}
                      onChange={(e) =>
                        editandoProducto
                          ? setEditandoProducto({ ...editandoProducto, precioOriginal: e.target.value })
                          : setNuevoProducto({ ...nuevoProducto, precioOriginal: e.target.value })
                      }
                      placeholder="1299"
                    />
                  </div>

                  <div>
                    <Label htmlFor="categoria">Categoría *</Label>
                    <select
                      id="categoria"
                      value={editandoProducto ? editandoProducto.categoria : nuevoProducto.categoria}
                      onChange={(e) =>
                        editandoProducto
                          ? setEditandoProducto({ ...editandoProducto, categoria: e.target.value })
                          : setNuevoProducto({ ...nuevoProducto, categoria: e.target.value })
                      }
                      className="w-full h-10 px-3 rounded-md border border-gray-300 bg-white"
                    >
                      <option value="iphone">iPhone</option>
                      <option value="mac">Mac</option>
                      <option value="ipad">iPad</option>
                      <option value="accesorios">Accesorios</option>
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="stock">Stock *</Label>
                    <Input
                      id="stock"
                      type="number"
                      value={editandoProducto ? editandoProducto.stock : nuevoProducto.stock}
                      onChange={(e) =>
                        editandoProducto
                          ? setEditandoProducto({ ...editandoProducto, stock: e.target.value })
                          : setNuevoProducto({ ...nuevoProducto, stock: e.target.value })
                      }
                      placeholder="25"
                    />
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="destacado"
                        checked={editandoProducto ? editandoProducto.destacado : nuevoProducto.destacado}
                        onChange={(e) =>
                          editandoProducto
                            ? setEditandoProducto({ ...editandoProducto, destacado: e.target.checked })
                            : setNuevoProducto({ ...nuevoProducto, destacado: e.target.checked })
                        }
                        className="rounded"
                      />
                      <Label htmlFor="destacado">Destacado</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="oferta"
                        checked={editandoProducto ? editandoProducto.oferta : nuevoProducto.oferta}
                        onChange={(e) =>
                          editandoProducto
                            ? setEditandoProducto({ ...editandoProducto, oferta: e.target.checked })
                            : setNuevoProducto({ ...nuevoProducto, oferta: e.target.checked })
                        }
                        className="rounded"
                      />
                      <Label htmlFor="oferta">En Oferta</Label>
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="descripcion">Descripción</Label>
                  <Textarea
                    id="descripcion"
                    value={editandoProducto ? editandoProducto.descripcion : nuevoProducto.descripcion}
                    onChange={(e) =>
                      editandoProducto
                        ? setEditandoProducto({ ...editandoProducto, descripcion: e.target.value })
                        : setNuevoProducto({ ...nuevoProducto, descripcion: e.target.value })
                    }
                    placeholder="Descripción detallada del producto..."
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="colores">Colores Disponibles</Label>
                    <Input
                      id="colores"
                      value={editandoProducto ? editandoProducto.colores : nuevoProducto.colores}
                      onChange={(e) =>
                        editandoProducto
                          ? setEditandoProducto({ ...editandoProducto, colores: e.target.value })
                          : setNuevoProducto({ ...nuevoProducto, colores: e.target.value })
                      }
                      placeholder="Titanio Natural, Titanio Azul, Titanio Blanco"
                    />
                    <p className="text-xs text-gray-500 mt-1">Separar con comas</p>
                  </div>

                  <div>
                    <Label htmlFor="capacidades">Capacidades</Label>
                    <Input
                      id="capacidades"
                      value={editandoProducto ? editandoProducto.capacidades : nuevoProducto.capacidades}
                      onChange={(e) =>
                        editandoProducto
                          ? setEditandoProducto({ ...editandoProducto, capacidades: e.target.value })
                          : setNuevoProducto({ ...nuevoProducto, capacidades: e.target.value })
                      }
                      placeholder="128GB, 256GB, 512GB, 1TB"
                    />
                    <p className="text-xs text-gray-500 mt-1">Separar con comas</p>
                  </div>
                </div>

                <div>
                  <Label htmlFor="imagen">URL de Imagen</Label>
                  <div className="flex gap-2">
                    <Input
                      id="imagen"
                      value={editandoProducto ? editandoProducto.imagen : nuevoProducto.imagen}
                      onChange={(e) =>
                        editandoProducto
                          ? setEditandoProducto({ ...editandoProducto, imagen: e.target.value })
                          : setNuevoProducto({ ...nuevoProducto, imagen: e.target.value })
                      }
                      placeholder="https://ejemplo.com/imagen.jpg"
                    />
                    <Button variant="outline">
                      <Upload className="h-4 w-4 mr-2" />
                      Subir
                    </Button>
                  </div>
                </div>

                <div className="flex gap-3">
                  {editandoProducto ? (
                    <>
                      <Button onClick={guardarEdicion} className="bg-blue-600 hover:bg-blue-700">
                        Guardar Cambios
                      </Button>
                      <Button variant="outline" onClick={() => setEditandoProducto(null)}>
                        Cancelar
                      </Button>
                    </>
                  ) : (
                    <Button onClick={agregarProducto} className="bg-green-600 hover:bg-green-700">
                      Agregar Producto
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Lista de Productos */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {productos.map((producto) => (
                <Card key={producto.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative h-48 bg-gray-100">
                      <Image
                        src={producto.imagen || "/placeholder.svg"}
                        alt={producto.nombre}
                        fill
                        className="object-contain p-4"
                      />
                      <div className="absolute top-2 right-2 flex gap-1">
                        {producto.destacado && <Badge className="bg-yellow-500">Destacado</Badge>}
                        {producto.oferta && <Badge className="bg-red-500">Oferta</Badge>}
                      </div>
                      <div className="absolute top-2 left-2">
                        <Badge variant="outline" className="bg-white">
                          Stock: {producto.stock}
                        </Badge>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-lg mb-2">{producto.nombre}</h3>
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">{producto.descripcion}</p>
                      <div className="flex justify-between items-center mb-3">
                        <div>
                          <span className="text-xl font-bold text-gray-900">${producto.precio.toLocaleString()}</span>
                          {producto.precioOriginal > producto.precio && (
                            <span className="text-sm text-gray-500 line-through ml-2">
                              ${producto.precioOriginal.toLocaleString()}
                            </span>
                          )}
                        </div>
                        <Badge variant="outline">{producto.categoria}</Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1" onClick={() => editarProducto(producto)}>
                          <Edit className="h-4 w-4 mr-1" />
                          Editar
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          onClick={() => eliminarProducto(producto.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Inventario */}
          <TabsContent value="inventario" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Control de Inventario</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Producto</th>
                        <th className="text-left p-2">Categoría</th>
                        <th className="text-left p-2">Stock Actual</th>
                        <th className="text-left p-2">Precio</th>
                        <th className="text-left p-2">Valor Total</th>
                        <th className="text-left p-2">Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {productos.map((producto) => (
                        <tr key={producto.id} className="border-b hover:bg-gray-50">
                          <td className="p-2 font-medium">{producto.nombre}</td>
                          <td className="p-2">{producto.categoria}</td>
                          <td className="p-2">
                            <Badge
                              variant={
                                producto.stock < 10 ? "destructive" : producto.stock < 20 ? "default" : "default"
                              }
                              className={
                                producto.stock < 10
                                  ? "bg-red-100 text-red-800"
                                  : producto.stock < 20
                                    ? "bg-yellow-100 text-yellow-800"
                                    : "bg-green-100 text-green-800"
                              }
                            >
                              {producto.stock}
                            </Badge>
                          </td>
                          <td className="p-2">${producto.precio.toLocaleString()}</td>
                          <td className="p-2">${(producto.precio * producto.stock).toLocaleString()}</td>
                          <td className="p-2">
                            {producto.stock < 10 ? (
                              <Badge variant="destructive">Stock Bajo</Badge>
                            ) : producto.stock < 20 ? (
                              <Badge className="bg-yellow-500">Stock Medio</Badge>
                            ) : (
                              <Badge className="bg-green-500">Stock Alto</Badge>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Configuración */}
          <TabsContent value="configuracion" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configuración de la Tienda</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nombreTienda">Nombre de la Tienda</Label>
                    <Input
                      id="nombreTienda"
                      value={configuracion.nombreTienda}
                      onChange={(e) => setConfiguracion({ ...configuracion, nombreTienda: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email de Contacto</Label>
                    <Input
                      id="email"
                      type="email"
                      value={configuracion.email}
                      onChange={(e) => setConfiguracion({ ...configuracion, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="telefono">Teléfono</Label>
                    <Input
                      id="telefono"
                      value={configuracion.telefono}
                      onChange={(e) => setConfiguracion({ ...configuracion, telefono: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="direccion">Dirección</Label>
                    <Input
                      id="direccion"
                      value={configuracion.direccion}
                      onChange={(e) => setConfiguracion({ ...configuracion, direccion: e.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="eslogan">Eslogan Principal</Label>
                  <Input
                    id="eslogan"
                    value={configuracion.eslogan}
                    onChange={(e) => setConfiguracion({ ...configuracion, eslogan: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="horarios">Horarios de Atención</Label>
                  <Input
                    id="horarios"
                    value={configuracion.horarios}
                    onChange={(e) => setConfiguracion({ ...configuracion, horarios: e.target.value })}
                  />
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Guardar Configuración</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Gestión de Imágenes */}
          <TabsContent value="imagenes" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Gestión de Imágenes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Subir Imágenes</h3>
                  <p className="text-gray-600 mb-4">Arrastra y suelta tus imágenes aquí o haz clic para seleccionar</p>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Upload className="h-4 w-4 mr-2" />
                    Seleccionar Archivos
                  </Button>
                  <p className="text-xs text-gray-500 mt-2">Formatos soportados: JPG, PNG, WebP (máx. 5MB)</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
